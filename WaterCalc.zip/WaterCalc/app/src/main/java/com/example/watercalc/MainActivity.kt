package com.example.watercalc

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding
import androidx.core.widget.doAfterTextChanged
import com.example.watercalc.databinding.ActivityMainBinding
import java.math.BigDecimal
import java.math.RoundingMode
import java.text.NumberFormat

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: SharedPreferences
    private var normalMessageColor = 0

    private val moneyFormat: NumberFormat = NumberFormat.getNumberInstance().apply {
        minimumFractionDigits = 2
        maximumFractionDigits = 2
    }

    private val volumeFormat: NumberFormat = NumberFormat.getNumberInstance().apply {
        minimumFractionDigits = 0
        maximumFractionDigits = 3
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Отступы под строку состояния, жестовую панель и клавиатуру
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { view, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or
                    WindowInsetsCompat.Type.displayCutout() or
                    WindowInsetsCompat.Type.ime()
            )
            view.updatePadding(
                left = bars.left,
                top = bars.top,
                right = bars.right,
                bottom = bars.bottom
            )
            insets
        }

        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        normalMessageColor = binding.tvMessage.currentTextColor

        // Тариф и показания запоминаются между запусками
        binding.etTariff.setText(prefs.getString(KEY_TARIFF, ""))
        binding.etPrevious.setText(prefs.getString(KEY_PREVIOUS, ""))
        binding.etCurrent.setText(prefs.getString(KEY_CURRENT, ""))

        binding.etTariff.doAfterTextChanged { update() }
        binding.etPrevious.doAfterTextChanged { update() }
        binding.etCurrent.doAfterTextChanged { update() }
        binding.btnRollOver.setOnClickListener { rollOver() }

        update()
    }

    /** Пересчитывает результат при любом изменении полей. */
    private fun update() {
        saveState()

        val previous = parse(binding.etPrevious.text)
        val current = parse(binding.etCurrent.text)
        val tariff = parse(binding.etTariff.text)

        if (previous == null || current == null) {
            show(null, null, getString(R.string.msg_enter_readings), false)
            return
        }
        if (current < previous) {
            show(null, null, getString(R.string.msg_current_less), true)
            return
        }

        val consumption = current - previous
        if (tariff == null) {
            show(consumption, null, getString(R.string.msg_enter_tariff), false)
            return
        }

        val total = (consumption * tariff).setScale(2, RoundingMode.HALF_UP)
        show(consumption, total, "", false)
    }

    private fun show(
        consumption: BigDecimal?,
        total: BigDecimal?,
        message: String,
        isError: Boolean
    ) {
        binding.tvConsumption.text = consumption
            ?.let { getString(R.string.volume_format, volumeFormat.format(it)) }
            ?: DASH
        binding.tvTotal.text = total?.let { moneyFormat.format(it) } ?: DASH

        binding.tvMessage.text = message
        binding.tvMessage.visibility = if (message.isEmpty()) View.GONE else View.VISIBLE
        binding.tvMessage.setTextColor(
            if (isError) ContextCompat.getColor(this, R.color.msg_error) else normalMessageColor
        )
    }

    /** Текущие показания становятся предыдущими, поле текущих очищается. */
    private fun rollOver() {
        val currentText = binding.etCurrent.text?.toString().orEmpty().trim()
        val current = parse(currentText)
        val previous = parse(binding.etPrevious.text)

        if (current == null) {
            Toast.makeText(this, R.string.msg_enter_current, Toast.LENGTH_SHORT).show()
            return
        }
        if (previous != null && current < previous) {
            Toast.makeText(this, R.string.msg_current_less, Toast.LENGTH_SHORT).show()
            return
        }

        binding.etPrevious.setText(currentText)
        binding.etCurrent.setText("")
        binding.etCurrent.requestFocus()
        Toast.makeText(this, R.string.msg_saved, Toast.LENGTH_SHORT).show()
    }

    private fun saveState() {
        prefs.edit()
            .putString(KEY_TARIFF, binding.etTariff.text?.toString().orEmpty())
            .putString(KEY_PREVIOUS, binding.etPrevious.text?.toString().orEmpty())
            .putString(KEY_CURRENT, binding.etCurrent.text?.toString().orEmpty())
            .apply()
    }

    /** Понимает и запятую, и точку как десятичный разделитель. */
    private fun parse(text: CharSequence?): BigDecimal? =
        text?.toString()?.trim()?.replace(',', '.')?.toBigDecimalOrNull()

    private companion object {
        const val PREFS = "water_calc"
        const val KEY_TARIFF = "tariff"
        const val KEY_PREVIOUS = "previous"
        const val KEY_CURRENT = "current"
        const val DASH = "—"
    }
}
